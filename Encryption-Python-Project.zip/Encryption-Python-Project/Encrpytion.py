import os
import sys
import base64
import hashlib
from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Hash import HMAC, SHA256

# Ensure the 'pycryptodome' package is installed
try:
    from Crypto.Cipher import AES
    from Crypto.Random import get_random_bytes
    from Crypto.Protocol.KDF import PBKDF2
    from Crypto.Hash import HMAC, SHA256
except ImportError:
    print("Please install the 'pycryptodome' package.")
    # sys.exit(1)  # Removed system exit

# Function to generate a 256-bit key from a passphrase and salt
def generate_key(passphrase: str, salt: bytes) -> bytes:
    """Generate a 256-bit key from a passphrase and salt."""
    return PBKDF2(passphrase, salt, dkLen=32, count=1000000, hmac_hash_module=SHA256)

# Function to encrypt a file using AES in CBC mode
def encrypt_file(file_path: str, key: bytes):
    """Encrypt the specified file using AES in CBC mode."""
    iv = get_random_bytes(16)  # Generate a random initialization vector (IV)
    cipher = AES.new(key, AES.MODE_CBC, iv)  # Create a new AES cipher object
    hmac = HMAC.new(key, digestmod=SHA256)  # Create a new HMAC object for integrity verification

    with open(file_path, 'rb') as f:
        plaintext = f.read()  # Read the file content
    
    # Padding to ensure the plaintext length is a multiple of 16 bytes
    padding_length = 16 - (len(plaintext) % 16)
    plaintext += bytes([padding_length]) * padding_length

    ciphertext = cipher.encrypt(plaintext)  # Encrypt the plaintext
    hmac.update(iv + ciphertext)  # Update HMAC with IV and ciphertext

    with open(file_path + '.enc', 'wb') as f:
        f.write(iv + ciphertext + hmac.digest())  # Write IV, ciphertext, and HMAC to the output file

# Function to decrypt a file using AES in CBC mode
def decrypt_file(file_path: str, key: bytes):
    """Decrypt the specified file using AES in CBC mode."""
    with open(file_path, 'rb') as f:
        iv = f.read(16)  # Read the initialization vector (IV)
        ciphertext = f.read()  # Read the rest of the file (ciphertext + HMAC)
        received_hmac = ciphertext[-32:]  # Extract the HMAC from the end
        ciphertext = ciphertext[:-32]  # Extract the ciphertext

    hmac = HMAC.new(key, digestmod=SHA256)  # Create a new HMAC object for integrity verification
    hmac.update(iv + ciphertext)  # Update HMAC with IV and ciphertext
    try:
        hmac.verify(received_hmac)  # Verify the HMAC
    except ValueError:
        print("HMAC verification failed. The file may be corrupted or tampered with.")
        return

    cipher = AES.new(key, AES.MODE_CBC, iv)  # Create a new AES cipher object
    plaintext = cipher.decrypt(ciphertext)  # Decrypt the ciphertext

    # Remove padding
    padding_length = plaintext[-1]
    plaintext = plaintext[:-padding_length]

    with open(file_path[:-4], 'wb') as f:
        f.write(plaintext)  # Write the decrypted plaintext to the output file

# Main function to handle command-line arguments and perform encryption/decryption
def main():
    if len(sys.argv) < 3:
        print("Usage: python Encryption.py --encrypt <file> or --decrypt <file>")
        sys.exit(1)

    command = sys.argv[1]
    file_path = sys.argv[2]

    passphrase = input("Enter passphrase: ")  # Prompt the user for a passphrase
    salt = b'some_salt'  # In a real application, use a securely stored salt
    key = generate_key(passphrase, salt)  # Generate the encryption key

    if command == '--encrypt':
        encrypt_file(file_path, key)  # Encrypt the file
        print(f"File {file_path} encrypted successfully.")
    elif command == '--decrypt':
        decrypt_file(file_path, key)  # Decrypt the file
        print(f"File {file_path} decrypted successfully.")
    else:
        print("Invalid command. Use --encrypt or --decrypt.")
        sys.exit(1)

if __name__ == "__main__":
    main()  # Run the main function

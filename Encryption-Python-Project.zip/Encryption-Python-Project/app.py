from flask import Flask, request, render_template, send_file
import os
from werkzeug.utils import secure_filename
from Crypto.Random import get_random_bytes
from Crypto.Protocol.KDF import PBKDF2
from Crypto.Hash import HMAC, SHA256
from Crypto.Cipher import AES

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SECRET_KEY'] = 'supersecretkey'

# Ensure the upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Function to generate a 256-bit key from a passphrase and salt
def generate_key(passphrase: str, salt: bytes) -> bytes:
    return PBKDF2(passphrase, salt, dkLen=32, count=1000000, hmac_hash_module=SHA256)

# Function to encrypt a file using AES in CBC mode
def encrypt_file(file_path: str, key: bytes):
    iv = get_random_bytes(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    hmac = HMAC.new(key, digestmod=SHA256)

    with open(file_path, 'rb') as f:
        plaintext = f.read()
    
    padding_length = 16 - (len(plaintext) % 16)
    plaintext += bytes([padding_length]) * padding_length

    ciphertext = cipher.encrypt(plaintext)
    hmac.update(iv + ciphertext)

    encrypted_file_path = file_path + '.enc'
    with open(encrypted_file_path, 'wb') as f:
        f.write(iv + ciphertext + hmac.digest())
    
    return encrypted_file_path

# Function to decrypt a file using AES in CBC mode
def decrypt_file(file_path: str, key: bytes):
    with open(file_path, 'rb') as f:
        iv = f.read(16)
        ciphertext = f.read()
        received_hmac = ciphertext[-32:]
        ciphertext = ciphertext[:-32]

    hmac = HMAC.new(key, digestmod=SHA256)
    hmac.update(iv + ciphertext)
    try:
        hmac.verify(received_hmac)
    except ValueError:
        return None

    cipher = AES.new(key, AES.MODE_CBC, iv)
    plaintext = cipher.decrypt(ciphertext)

    padding_length = plaintext[-1]
    plaintext = plaintext[:-padding_length]

    decrypted_file_path = file_path[:-4]
    with open(decrypted_file_path, 'wb') as f:
        f.write(plaintext)
    
    return decrypted_file_path

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/encrypt', methods=['POST'])
def encrypt():
    file = request.files['file']
    passphrase = request.form['passphrase']
    salt = b'some_salt'
    key = generate_key(passphrase, salt)

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(file_path)

    encrypted_file_path = encrypt_file(file_path, key)
    return send_file(encrypted_file_path, as_attachment=True)

@app.route('/decrypt', methods=['POST'])
def decrypt():
    file = request.files['file']
    passphrase = request.form['passphrase']
    salt = b'some_salt'
    key = generate_key(passphrase, salt)

    filename = secure_filename(file.filename)
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(file_path)

    decrypted_file_path = decrypt_file(file_path, key)
    if decrypted_file_path:
        return send_file(decrypted_file_path, as_attachment=True)
    else:
        return "HMAC verification failed. The file may be corrupted or tampered with.", 400

if __name__ == '__main__':
    app.run(debug=True)
